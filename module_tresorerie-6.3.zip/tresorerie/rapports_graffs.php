<?php

$res=0;
if (! $res && file_exists("../main.inc.php")) $res=@include("../main.inc.php");       // For root directory
if (! $res && file_exists("../../main.inc.php")) $res=@include("../../main.inc.php"); // For "custom" 

global $conf;
if (!$conf->tresorerie->enabled) {
  accessforbidden();
}
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formother.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture-rec.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/bank/class/account.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/paiement/class/paiement.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/facture/modules_facture.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/discount.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/invoice.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions2.lib.php';

require_once DOL_DOCUMENT_ROOT.'/core/class/dolgraph.class.php';





dol_include_once("/tresorerie/class/tresorerie.class.php");

$form        = new Form($db);
$formother   = new FormOther($db);
$userstatic  = new User($db);
$tresorerie  = new tresorerie($db);
$modname = $langs->trans("tresorerie");


$srch_year = GETPOST('srch_year') ? GETPOST('srch_year') : date('Y');
$langs->load('tresorerie');
$langs->loadLangs(array('bills', 'companies', 'compta', 'products', 'banks', 'main', 'withdrawals', 'loan'));
$arr_mois = monthArray($langs,1);

$morejs  = array();
llxHeader(array(), $modname,'','','','',$morejs,0,0);

print load_fiche_titre($modname);



print '<link rel="stylesheet" type="text/css" href="'.dol_buildpath('/tresorerie/css/style.css',1).'">';
// print '<script src="'.dol_buildpath('/tresorerie/js/plugin/core.js',1).'"></script>';
// print '<script src="'.dol_buildpath('/tresorerie/js/plugin/charts.js',1).'"></script>';
// print '<script src="'.dol_buildpath('/tresorerie/js/plugin/animated.js',1).'"></script>';



print '<form  method="POST" action="'.$_SERVER['PHP_SELF'].'?facid='.$facid.'" id="formtresorerie" >';
    print '<input type="hidden" name="srch_nbmonth" value="'.$srch_nbmonth.'">';
    print '<input type="hidden" name="srch_year" value="'.$srch_year.'">';
    print '<table width="100%">';
        print '<tr><td style="width:33%">';
            print $langs->trans('Year').': ';
            $formother->select_year($srch_year ? $srch_year : -1, 'srch_year', 1, 20, 5);
        print '</td></tr>';
    print '</table>';
print '</form>';
print '<br>';
print '<div id="EtatTresorerie">';
               
    $sql = "SELECT s.nom as name, s.rowid as socid,  sum(pf.amount) as amount_ttc, MONTH(p.datep) as month";
    $sql .= " FROM ".MAIN_DB_PREFIX."societe as s";
    $sql .= ", ".MAIN_DB_PREFIX."facture as f";
    $sql .= ", ".MAIN_DB_PREFIX."paiement_facture as pf";
    $sql .= ", ".MAIN_DB_PREFIX."paiement as p";
    $sql .= " WHERE p.rowid = pf.fk_paiement";
    $sql .= " AND pf.fk_facture = f.rowid";
    $sql .= " AND f.fk_soc = s.rowid";
    if (!empty($srch_year)){
        $sql .= " AND YEAR(p.datep) =".$srch_year;
    }
    $sql .= " AND f.entity IN (".getEntity('invoice').")";
    if ($socid) $sql .= " AND f.fk_soc = ".$socid;
    $sql .= " GROUP BY name, socid, month";

    $result = $db->query($sql);
    if ($result) {
        $num = $db->num_rows($result);
        $i = 0;
        while ($i < $num)
        {
            $objp = $db->fetch_object($result);
            $datatotal['revenus']['BillsCustomers'] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
            $datatotal['revenus']['total'] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
            $totalg['revenus'][$objp->month] += $objp->amount_ttc;
            $i++;
        }
        $db->free($result);
    } 


    $sql = "SELECT p.societe as nom, MONTH(p.datedon) as month, p.firstname, p.lastname, date_format(p.datedon,'%Y-%m') as dm, sum(p.amount) as amount";
    $sql .= " FROM ".MAIN_DB_PREFIX."don as p";
    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."payment_donation as pe ON pe.fk_donation = p.rowid";
    $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."c_paiement as c ON pe.fk_typepayment = c.id";
    $sql .= " WHERE p.entity IN (".getEntity('donation').")";
    $sql .= " AND fk_statut >= 2";
    if (!empty($srch_year))
    $sql .= " AND YEAR(p.datedon) = '".$srch_year."'";
    // $sql .= " GROUP BY p.societe, p.firstname, p.lastname, dm";

    $sql .= $db->order($newsortfield, $sortorder);

    $result = $db->query($sql);
    if ($result)
    {
        $numd = $db->num_rows($result);
        $i = 0;
        if ($numd)
        {
            while ($i < $numd)
            {
                $obj = $db->fetch_object($result);
                $datatotal['revenus']['Donations'] += $obj->amount;
                $datatotal['revenus']['total'] += $obj->amount;
                
                $totalg['revenus'][$obj->month] += $obj->amount;

                $i++;
            }   
        }
    }

   
    //  TVA
    $sql = "SELECT date_format(t.datev,'%Y-%m') as dm, MONTH(t.datev) as month, sum(t.amount) as amount";
    $sql .= " FROM ".MAIN_DB_PREFIX."tva as t";
    $sql .= " WHERE amount < 0";
    if (!empty($srch_year) )
        $sql .= " AND YEAR(t.datev) =".$srch_year;

    $sql .= " AND t.entity = ".$conf->entity;
    $sql .= " GROUP BY dm, month";

    dol_syslog("get vat really received back", LOG_DEBUG);
    $result = $db->query($sql);
    if ($result) {
        $num = $db->num_rows($result);
        $i = 0;
        if ($num) {
            while ($i < $num) {
                $obj = $db->fetch_object($result);
                $datatotal['revenus']['VATCollected'] += -$obj->amount;
                $datatotal['revenus']['total'] += -$obj->amount;
                $totalg['revenus'][$obj->month] += -$obj->amount;

                $i++;
            }
        }
    }

    $sql = "SELECT s.nom as name, s.rowid as socid, sum(pf.amount) as amount_ttc, MONTH(p.datep) as month";
$sql .= " FROM ".MAIN_DB_PREFIX."paiementfourn as p";
$sql .= ", ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf";
$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."facture_fourn as f";
$sql .= " ON pf.fk_facturefourn = f.rowid";
$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."societe as s";
$sql .= " ON f.fk_soc = s.rowid";
$sql .= " WHERE p.rowid = pf.fk_paiementfourn ";

if (!empty($srch_year)){
    $sql .= " AND YEAR(p.datep) =".$srch_year;
}
$sql .= " AND f.entity IN (".getEntity('invoice').")";
if ($socid) $sql .= " AND f.fk_soc = ".$socid;
$sql .= " GROUP BY name, socid, month";
$sql .= $db->order($sortfield, $sortorder);
dol_syslog("get customer invoices", LOG_DEBUG);
$result = $db->query($sql);
if ($result) {
    $num = $db->num_rows($result);
    $i = 0;
    while ($i < $num)
    {
        $objp = $db->fetch_object($result);
        $datatotal['depenses']['SuppliersInvoices'] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
        $datatotal['depenses']['total'] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
        $totalg['depenses'][$objp->month] += $objp->amount_ttc;
        $i++;
    }
    $db->free($result);
} 


$sql = "SELECT cs.rowid as rowid, c.id, c.libelle as label, sum(p.amount) as amount, MONTH(p.datep) as month";
$sql .= " FROM ".MAIN_DB_PREFIX."c_chargesociales as c";
$sql .= ", ".MAIN_DB_PREFIX."chargesociales as cs";
$sql .= ", ".MAIN_DB_PREFIX."paiementcharge as p";
$sql .= " WHERE p.fk_charge = cs.rowid";
$sql .= " AND cs.fk_type = c.id";
$sql .= " AND c.deductible = 0";

if (!empty($srch_year)){
    $sql .= " AND YEAR(p.datep) =".$srch_year;
}

$sql .= " AND cs.entity = ".$conf->entity;
$sql .= " GROUP BY c.libelle, c.id, month";

$result = $db->query($sql);
if ($result) {
    $num = $db->num_rows($result);
    $i = 0;
    if ($num) {
        while ($i < $num) {
            $obj = $db->fetch_object($result);

            $datatotal['depenses']['SocialContributionsNondeductibles'] += $obj->amount;
            $datatotal['depenses']['total'] += $obj->amount;
            $totalg['depenses'][$obj->month] += $obj->amount;
            $i++;
        }
    }
}

$sql = "SELECT cs.rowid as rowid, c.id, c.libelle as label, sum(p.amount) as amount, MONTH(p.datep) as month";
$sql .= " FROM ".MAIN_DB_PREFIX."c_chargesociales as c";
$sql .= ", ".MAIN_DB_PREFIX."chargesociales as cs";
$sql .= ", ".MAIN_DB_PREFIX."paiementcharge as p";
$sql .= " WHERE p.fk_charge = cs.rowid";
$sql .= " AND cs.fk_type = c.id";
$sql .= " AND c.deductible = 1";

if (!empty($srch_year)){
    $sql .= " AND YEAR(p.datep) =".$srch_year;
}

$sql .= " AND cs.entity = ".$conf->entity;
$sql .= " GROUP BY c.libelle, c.id, month";
// $newsortfield = $sortfield;
// if ($newsortfield == 's.nom, s.rowid') $newsortfield = 'c.libelle, c.id';
// if ($newsortfield == 'amount_ht') $newsortfield = 'amount';
// if ($newsortfield == 'amount_ttc') $newsortfield = 'amount';
// $sql .= $db->order($newsortfield, $sortorder);
dol_syslog("get social contributions deductible=1", LOG_DEBUG);
$result = $db->query($sql);
if ($result) {
    $num = $db->num_rows($result);
    $i = 0;
    if ($num) {
        while ($i < $num) {
            $obj = $db->fetch_object($result);

            $datatotal['depenses']['SocialContributionsDeductibles'] +=$obj->amount;
            $datatotal['depenses']['total'] +=$obj->amount;
               $totalg['depenses'][$obj->month] += $obj->amount;
            $i++;
        }
    }
}

    $sql = "SELECT u.rowid, u.firstname, u.lastname, p.fk_user, p.label as label, MONTH(p.datep) as month, date_format(p.datep,'%Y-%m') as dm, sum(p.amount) as amount";
    $sql .= " FROM ".MAIN_DB_PREFIX."payment_salary as p";
    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."user as u ON u.rowid=p.fk_user";
    $sql .= " WHERE p.entity IN (".getEntity('payment_salary').")";
    if (!empty($srch_year) )
        $sql .= " AND YEAR(p.datep) = ".$srch_year;

    $sql .= " GROUP BY u.rowid, u.firstname, u.lastname, p.fk_user, p.label, dm, month";
    // $sql .= $db->order($newsortfield, $sortorder);
    $result = $db->query($sql);
    if ($result)
    {
        $num = $db->num_rows($result);
        $i = 0;
        if ($num)
        {
            while ($i < $num)
            {
                $obj = $db->fetch_object($result);

                $datatotal['depenses']['Salaries'] +=$obj->amount;
                $datatotal['depenses']['total'] +=$obj->amount;
                   $totalg['depenses'][$obj->month] += $obj->amount;
                $i++;
            }
        }
    }
     

    $sql = "SELECT p.rowid, p.ref, u.rowid as userid, u.firstname, u.lastname, date_format(pe.datep,'%Y-%m') as dm, sum(p.total_ht) as amount_ht, sum(p.total_ttc) as amount_ttc, MONTH(pe.datep) as month";
    $sql .= " FROM ".MAIN_DB_PREFIX."expensereport as p";
    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."user as u ON u.rowid=p.fk_user_author";
    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."payment_expensereport as pe ON pe.fk_expensereport = p.rowid";
    $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."c_paiement as c ON pe.fk_typepayment = c.id";
    $sql .= " WHERE p.entity IN (".getEntity('expensereport').")";
    $sql .= " AND p.fk_statut>=5";

    if (!empty($srch_year) )
    {
        $sql .= " AND YEAR(pe.datep) =".$srch_year;
    }

    $sql .= " GROUP BY u.rowid, p.rowid, p.ref, u.firstname, u.lastname, dm, month";
    $result = $db->query($sql);
        if ($result)
        {
            $num = $db->num_rows($result);
            $i = 0;
            if($num > 1)
            if ($num)
            {
                while ($i < $num)
                {
                    $obj = $db->fetch_object($result);
                    $datatotal['depenses']['ExpenseReport'] += $obj->amount_ttc;
                    $datatotal['depenses']['total'] += $obj->amount_ttc;
                       $totalg['depenses'][$obj->month] += $obj->amount_ttc;
                    $i++;
                }
            }
        }

        $sql = "SELECT SUM(p.amount) AS amount, MONTH(p.datep) as month FROM ".MAIN_DB_PREFIX."payment_various as p";
        $sql .= ' WHERE p.entity IN ('.getEntity('payment_various');
        if (!empty($srch_year) )
            $sql .= " AND YEAR(p.datep) =".$srch_year;

        $sql .= ' GROUP BY p.sens, month';
        $sql .= ' ORDER BY p.sens';

        dol_syslog('get various payments', LOG_DEBUG);
        $result = $db->query($sql);
        if ($result)
        {
            // Debit
            $num = $db->num_rows($result);
            $i = 0;
            if ($num)
            {
                while ($i < $num)
                {
                    $obj = $db->fetch_object($result);
                    $datatotal['depenses']['VariousPayment'] += $obj->amount;
                    $datatotal['depenses']['total'] += $obj->amount;
                    $totalg['depenses'][$obj->month] += $obj->amount;
                    $i++;
                }
            }
        }

    $sql = 'SELECT l.rowid as id, l.label AS label, SUM(p.amount_capital + p.amount_insurance + p.amount_interest) as amount, MONTH(p.datep) as month FROM '.MAIN_DB_PREFIX.'payment_loan as p';
    $sql .= ' LEFT JOIN '.MAIN_DB_PREFIX.'loan AS l ON l.rowid = p.fk_loan';
    $sql .= ' WHERE 1 = 1';

    if (!empty($srch_year) )
        $sql .= " AND YEAR(p.datep) =".$srch_year;

    $sql .= ' GROUP BY p.fk_loan, month ';
    $sql .= ' ORDER BY p.fk_loan';
    $result = $db->query($sql);
    if ($result)
    {
        $num = $db->num_rows($result);
        if ($num)
        {
            while ($obj = $db->fetch_object($result))
            {

                $datatotal['depenses']['PaymentLoan'] += $obj->amount;
                $datatotal['depenses']['total'] += $obj->amount;
                $totalg['depenses'][$obj->month] += $obj->amount;
            }
        }
    }
   // VAT

    $sql = "SELECT date_format(t.datev,'%Y-%m') as dm, sum(t.amount) as amount, MONTH(t.datev) as month";
    $sql .= " FROM ".MAIN_DB_PREFIX."tva as t";
    $sql .= " WHERE amount > 0";
    if (!empty($srch_year))
        $sql .= " AND YEAR(t.datev) = ".$srch_year;
    $sql .= " AND t.entity = ".$conf->entity;
    $sql .= " GROUP BY dm, month";

    dol_syslog("get vat really paid", LOG_DEBUG);
    $result = $db->query($sql);
    if ($result) {
        $num = $db->num_rows($result);
        $i = 0;
        if ($num) {
            while ($i < $num) {
                $obj = $db->fetch_object($result);
                $datatotal['depenses']['VATPaid'] += $obj->amount;
                $datatotal['depenses']['total'] += $obj->amount;
                $totalg['depenses'][$obj->month] += $obj->amount;
                $i++;
            }
        }
    }
    $totrev = $datatotal['revenus']['total'];
    if($datatotal['depenses']){
        foreach ($datatotal['revenus'] as $key => $value) {
            if($key != 'total'){
                $percent =0;
                if($totrev && $value){
                    $percent = ($value*100)/$totrev;
                    $percent= number_format($percent, 1, '.', '');
                }
                $datarevenus[$i][0] = html_entity_decode(preg_replace( "/\r|\n/", "", dol_escape_js($langs->trans($key)))).': '.$percent.'%';
                $datarevenus[$i][1] = $value;
            }
            $i++;
        }
    }
    
    $totdep = $datatotal['depenses']['total'];

    if($datatotal['depenses']){
        foreach ($datatotal['depenses'] as $key => $value) {
            if($key != 'total'){
                $percent = 0;
                if($totrev && $value){
                    $percent = ($value*100)/$totdep;
                    $percent= number_format($percent, 1, '.', '');
                }
                $datadepenses[$i][0] = html_entity_decode(preg_replace( "/\r|\n/", "", dol_escape_js($langs->trans($key)))).': '.$percent.'%';
                $datadepenses[$i][1] = $value;
            }
            $i++;
        }
    }
    

    foreach ($arr_mois as $key => $value) {
        $dt[$key-1][0] = html_entity_decode($value);
        $dt[$key-1][1] = ($totalg['revenus'][$key]) ? $totalg['revenus'][$key] : 0;
        $dt[$key-1][2] = ($totalg['depenses'][$key]) ? $totalg['depenses'][$key] : 0;
    }


    print '<div style="width:100%; float:left">';
    print '<div id="revenus">';
        print '<div class="title_graf">'.$langs->trans("graffs_revenus").'</div>';
        print '<div id="chartdiv1" style="text-align:center; height: 400px;margin-right:30px;">';
            print '<br>';
            // print '<div style="line-height: 400px;"><div class="lds-ring" align="center"><div></div><div></div><div></div><div></div></div></div>';
            $dolgraph = new DolGraph();
            $dolgraph->SetData($datarevenus);
            $dolgraph->setShowLegend(1);
            $dolgraph->setShowPercent(1);
            $dolgraph->SetType(array('pie'));
            $dolgraph->setWidth('100%');
            $dolgraph->SetHeight(180);
            $dolgraph->SetLegendWidthMin(2);
            $dolgraph->draw('idgraphstatus');

            print $dolgraph->show(0);

        print '</div>';
    print '</div>';

    print '<div id="depenses">';
        print '<div class="title_graf">'.$langs->trans("graffs_depenses").'</div>';
        print '<div id="chartdiv2" style="text-align:center; height: 400px;">';
        print '<br>';
            // print '<div style="line-height: 400px;"><div class="lds-ring" align="center"><div></div><div></div><div></div><div></div></div></div>';
            $dolgraph2 = new DolGraph();
            $dolgraph2->SetData($datadepenses);
            $dolgraph2->setShowLegend(1);
            $dolgraph2->setShowPercent(1);
            $dolgraph2->SetType(array('pie'));
            $dolgraph2->setWidth('100%');
            $dolgraph2->SetHeight(180);
            $dolgraph2->SetLegendWidthMin(2);
            $dolgraph2->draw('idgraphstatus2');

            print $dolgraph2->show(0);
        print '</div>';
    print '</div>';

    print '</div>';
    print '<div id="tresor_total">';
        print '<div class="title_graf">'.$langs->trans("graffs_tresor").' - '.$langs->trans("Year").' '.$srch_year.'</div>';
        print '<div id="chartdiv3" style="text-align:center; height: 500px;">';
            $filenamenb = $dir.'/shipmentsnbinyear5'.$year.'.png';
            $px1 = new DolGraph();
            $mesg = $px1->isGraphKo();
            if (! $mesg)
            {   
                $data = $dt;
                $px1->SetData($data);
                $legend=array();

                    $legend[0]=html_entity_decode($langs->trans("Income"));
                    $legend[1]=html_entity_decode($langs->trans("Outcome"));

                $px1->SetLegend($legend);
                $px1->SetMaxValue($px1->GetCeilMaxValue());
                $px1->SetMinValue(min(0, $px1->GetFloorMinValue()));
                $px1->SetWidth('100%');
                $px1->SetHeight(180);
                $px1->SetYLabel($langs->trans("NbOfSendings"));
                $px1->SetShading(3);
                $px1->SetHorizTickIncrement(1);
                $px1->mode='depth';

                $px1->draw('idgraphstatus3');
            }

            print $px1->show();
        print '</div>';
    print '</div>';
    
print  '</div>';
          
