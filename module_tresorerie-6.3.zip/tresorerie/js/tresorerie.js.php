<?php 
if (!defined('NOREQUIRESOC'))    define('NOREQUIRESOC', 1);
if (!defined('NOCSRFCHECK'))     define('NOCSRFCHECK', 1);
if (!defined('NOTOKENRENEWAL'))  define('NOTOKENRENEWAL', 1);
if (!defined('NOREQUIREHTML'))   define('NOREQUIREHTML', 1);
if (!defined('NOREQUIREAJAX'))   define('NOREQUIREAJAX', 1);
define('ISLOADEDBYSTEELSHEET', '1');
session_cache_limiter('public');

$res=0;
if (! $res && file_exists("../../main.inc.php")) $res=@include("../../main.inc.php");       // For root directory
if (! $res && file_exists("../../../main.inc.php")) $res=@include("../../../main.inc.php"); // For "custom" 

dol_include_once('/core/lib/functions.lib.php');

// Define mime type
top_httphead('text/javascript; charset=UTF-8');
global $langs;
$var = false;

?>

$(document).ready(function(){
    $('#nb_month').change(function(){
        $('#formtresorerie').submit();
    }); 
    $('#srch_year').change(function(){
        $('#formtresorerie').submit();
    }); 

    $('#typeshow_all').change(function() {
        $('table.depenses').show();
        $('table.revenus').show();
        $('.show_lign').each(function(){
            $(this).trigger("click");
        });
    })
   
    $('#typeshow_elem').change(function() {
        $('.hide_lign').each(function(){
            $(this).trigger("click");
        });
    })
   

});

function showhide_lign(that) {

    var elem =$(that).parent('td');
    var id = elem.data('label');
    if($(that).hasClass("show_lign")){

        if($('.tab_'+id).find('.tr-pagination').length<=0)
            GoToPage(0,id);
        else
            $("."+id).slideDown(100);
        $('.total_'+id).find('.show_lign i').css({
            '-moz-transform':'rotate(180deg)',
            '-webkit-transform':'rotate(180deg)',
            '-o-transform':'rotate(180deg)',
            '-ms-transform':'rotate(180deg)',
            'transform': 'rotate(180deg)',
            'transition-duration': '0.5s'
        });  
        $('.total_'+id).find('span').removeClass('show_lign');
        $('.total_'+id).find('span').addClass('hide_lign');
           
    }
    else if($(that).hasClass("hide_lign")){
        $('.total_'+id).find('.hide_lign i').css({
            '-moz-transform':'rotate(360deg)',
            '-webkit-transform':'rotate(360deg)',
            '-o-transform':'rotate(360deg)',
            '-ms-transform':'rotate(360deg)',
            'transform': 'rotate(360deg)',
            'transition-duration': '0.5s'
        });  
        $("."+id).slideUp(100);
        $('.total_'+id).find('span').removeClass('hide_lign');
        $('.total_'+id).find('span').addClass('show_lign');
           
    }
}


function GoToPage(page,id_element='',nb_lign=3) {
    var element = $('tr.total_'+id_element);
    var sql = $(element).find('.sql').val();
    var color = $(element).find('.color').val();
    var year = $('#srch_year').val();
    var nb_month = $('#nb_month').val();
    if($.isNumeric(page))
        var topage = page;
    else
        var topage = $(page).find('.topage').val();

    $.ajax({
        data:{"sql":sql,"year":year,"nb_month":nb_month,"topage":topage,"nb_lign":nb_lign,'id_element':id_element,'color':color},
        url:'<?php echo dol_escape_js(dol_buildpath("/tresorerie/ajax/pagination.php",1)); ?>',
        type:'POST',
        dataType: 'Json',
        success:function(json){
            if(json['error']){
                $('.tab_'+id_element).find('tbody').html(json['error']);
            } else {
                $('.tab_'+id_element).find('tbody tr').remove();
                $('.tab_'+id_element).find('thead tr.tr-pagination').remove();
                $('.tab_'+id_element).find('tbody').html(json['element']);
                $(json['pagination']).insertBefore(element);
                $('.tab_'+id_element).find('thead tr.trclean').hide();
                $("tr."+id_element).slideDown(100);
            }

        }
    });

}
function change_nbligne(x,element) {
    var nb_lign = $(x).val();
    GoToPage(0,element,nb_lign);
}

function show_depenses(x) {
    var id = $(x).data('elem');
    if($(x).hasClass("show_depenses")){
        $(x).find('i').css({
            '-moz-transform':'rotate(180deg)',
            '-webkit-transform':'rotate(180deg)',
            '-o-transform':'rotate(180deg)',
            '-ms-transform':'rotate(180deg)',
            'transform': 'rotate(180deg)',
            'transition-duration': '0.5s'
        }); 
        $(x).removeClass('show_depenses');
        $(x).addClass('hide_depenses');
        $('.'+id).hide();
           
    }
    else if($(x).hasClass("hide_depenses")){
        $(x).find('i').css({
            '-moz-transform':'rotate(360deg)',
            '-webkit-transform':'rotate(360deg)',
            '-o-transform':'rotate(360deg)',
            '-ms-transform':'rotate(360deg)',
            'transform': 'rotate(360deg)',
        });  
        $(x).removeClass('hide_depenses');
        $(x).addClass('show_depenses');
        $('.'+id).show();
    }
}

function show_revenus(x) {
     var id = $(x).data('elem');
    if($(x).hasClass("show_revenus")){
        $(x).find('i').css({
            '-moz-transform':'rotate(180deg)',
            '-webkit-transform':'rotate(180deg)',
            '-o-transform':'rotate(180deg)',
            '-ms-transform':'rotate(180deg)',
            'transform': 'rotate(180deg)',
            'transition-duration': '0.5s'
        }); 
        $(x).removeClass('show_revenus');
        $(x).addClass('hide_revenus');
        $('.'+id).hide();
           
    }
    else if($(x).hasClass("hide_revenus")){
        $(x).find('i').css({
            '-moz-transform':'rotate(360deg)',
            '-webkit-transform':'rotate(360deg)',
            '-o-transform':'rotate(360deg)',
            '-ms-transform':'rotate(360deg)',
            'transform': 'rotate(360deg)',
        });  
        $(x).removeClass('hide_revenus');
        $(x).addClass('show_revenus');
        $('.'+id).show();
    }
}