<?php 

$html .='<style>';
    $html .='#EtatTresorerie .td_grey{
        background-color: #eaeaea;
        padding: 7px;
    }

    #EtatTresorerie .td_vide {
        background-color: #fff;
        border: 0px;
        padding: 7px;
    }

    #EtatTresorerie .td_vert {
        padding: 7px;
        background-color: #99cc00;
        color: #fff;
        border: 0px;
    }

    #EtatTresorerie .td_vert_curent{
        color: #fff;
        font-weight: bold;
        border-top: 1px solid #a9c390;
        border-right: 1px solid #a9c390;
        border-bottom: 1px solid #a9c390;
        border-left: 1px solid #bbdbf5;
        background-color: #99cc00;
    }

    #revenus .liste_total td{
        background-color: #99cc00;
    }

    #EtatTresorerie .td_curent{
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        border-left: 1px solid #ccc;
        background-color: #ddf8d0;
        padding: 0.2em 0.4em 0.2em 0.2em;
        color: #333;
    }

    #EtatTresorerie .td_orang {
        padding: 7px;
        background-color: #f38400;
        color: #fff;
        border: 0px;
    }

    #EtatTresorerie .td_orang_curent{
        color: #fff;
        font-weight: bold;
        border-top: 1px solid #a9c390;
        border-right: 1px solid #a9c390;
        border-bottom: 1px solid #a9c390;
        border-left: 1px solid #bbdbf5;
        background-color: #f38400;
    }

    #depenses .liste_total td{
        background-color: #f38400;
    }

    #depenses .td_curent{
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        border-left: 1px solid #ccc;
        background-color: #fbd4a1;
        padding: 0.2em 0.4em 0.2em 0.2em;
        color: #333;
    }

    #EtatTresorerie .trclean{
        background-color: #fff !important;
    }

    #EtatTresorerie table:first-child{
        border-top: 0px !important; 
    }

    #EtatTresorerie .td_label{
        width: 130px;
        max-width: 130px !important;
        /*text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;*/
    }
    #EtatTresorerie .trclean td{
        border:0px !important;
    }

    #EtatTresorerie tr.liste_total td{
        color: #fff !important;
    }

    #EtatTresorerie .hide_lign{
    }

    #EtatTresorerie .td_label span.show_lign, #EtatTresorerie .td_label span.hide_lign{
        font-size: 12px;
        float: right;
        cursor: pointer;
        color: #696969;
        line-height: 1.7;
    }

    #EtatTresorerie tr.lign_total{
        background-color: #e9eaed !important;
    }

    #EtatTresorerie #revenus tr.liste_titre, #EtatTresorerie #depenses tr.liste_titre{
        background-color: #dadbdd !important;
    }

    #EtatTresorerie tr.lignes_show{
        display: table-row;
    }

    #EtatTresorerie tr.lignes_hide{
        display: none;
    }

    #EtatTresorerie #revenus tr.liste_titre td.td_vide {
        color: #fff !important;
        background-color: #99cc00 !important;
        font-weight: bold;
    }
    #EtatTresorerie #depenses tr.liste_titre td.td_vide {
        color: #fff !important;
        background-color: #f38400 !important;
        font-weight: bold;
    }';
$html .='</style>';

$html .= '<br>'; 

$html .= '<table border="0" width="100%" class="headertabnoborder" cellpadding="0" cellspaccing="0"  style="width:100%">'; 
    $html .= '<tr>';

        $html .= '<td style="width:40%" align="left">';
            global $mysoc;
            $carac_soci = $langs->convToOutputCharset($mysoc->name);
            $html .= '<h3>';
            $html .= $carac_soci;
            $html .= '</h3>';
            $html .= '<h4>';
            $html .= '</h4>'; 
        $html .= '</td>'; 

        $periods = explode('-', $item->period);
        $periodyear = $periods[0] + 0;
        $periodmonth = $periods[1];

        $html .= '<td  style="width:40%" align="left">'; 
            $html .= '<h1>';
            $html .= $langs->trans('etattresorerie').' - '.$langs->trans('Year').': '.$srch_year;  
            $html .= '</h1>';
        $html .= '</td>';  

    $html .= '</tr>';
$html .= '</table>';

$html .= '<br>';
$html .= '<br>';

$arr_mois = monthArray($langs,1);

$html .='<div id="EtatTresorerie">';

    $html .= '<div id="revenus">';
        $html .= '<table  cellpadding="0px" cellspacing="0" width="100%">';
            $html .= '<input type="hidden" name="action" value="generer">';
            $html .= '<tr>';
                $html .= '<td class="td_vert" style="background-color:#99cc00;width:1%"></td>';
                $html .= '<td class="td_vert" style="background-color:#99cc00;width:1%"></td>';
                $html .= '<td class="td_vert" style="background-color:#99cc00;width:1%"></td>';
                $html .= '<td class="td_vert" style="background-color:#99cc00;width:1%"></td>';
                $html .= '<td colspan="" style="background-color:#99cc00;color:white;width:11%;line-height: 2;" align="left">'.$langs->trans("Income").'</td>';
                foreach ($arr_mois as $key => $value) {
                    $cls='style="background-color: #dadbdd;line-height:2;width:7%;"';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='style="background-color: #99cc00;line-height:2;width:7%;" ';
                    $html .= '<td '.$cls.' align="center">';
                        $html .= $value;
                    $html .= '</td>';
                    if($key == $srch_nbmonth){
                        break;
                    }
                }
            $html .= '</tr>';
            $html .= '<tr class="trclean"><td class="td_vert" style="background-color:#99cc00"></td><td colspan="16"></td></tr>';
            $html .= '<tr>';
                $html .= '<td class="td_vert" style="background-color:#99cc00;width:1%"></td>';
                $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';
                $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';
                $html .= '<td class="td_label" style="background-color:#e9eaed;line-height: 2;" title="'.$langs->trans('BillsCustomers').'">'.$langs->trans('BillsCustomers').'<span class="show_lign" data-element="BillsCustomers" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';
               
                $sql = "SELECT s.nom as name, s.rowid as socid,  sum(pf.amount) as amount_ttc, MONTH(p.datep) as month";
                $sql .= " FROM ".MAIN_DB_PREFIX."societe as s";
                $sql .= ", ".MAIN_DB_PREFIX."facture as f";
                $sql .= ", ".MAIN_DB_PREFIX."paiement_facture as pf";
                $sql .= ", ".MAIN_DB_PREFIX."paiement as p";
                $sql .= " WHERE p.rowid = pf.fk_paiement";
                $sql .= " AND pf.fk_facture = f.rowid";
                $sql .= " AND f.fk_soc = s.rowid";
                if (!empty($srch_year)){
                    $sql .= " AND YEAR(p.datep) =".$srch_year;
                }
                $sql .= " AND f.entity IN (".getEntity('invoice').")";
                if ($socid) $sql .= " AND f.fk_soc = ".$socid;
                $sql .= " GROUP BY name, socid, month";

                $result = $db->query($sql);
                if ($result) {
                    $num = $db->num_rows($result);
                    $i = 0;
                    while ($i < $num)
                    {
                        $objp = $db->fetch_object($result);
                        $data[$objp->socid][$objp->month]['montant_ttc'] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
                        $data[$objp->socid]['label'] = $objp->name;
                        $total[$objp->month] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
                        $i++;
                    }
                    $db->free($result);
                } 

                foreach ($arr_mois as $key => $value) {
                    $cls='style="background-color:#eaeaea;line-height: 2;"';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='style="background-color:#ddf8d0;line-height: 2;"';
                    $html .= '<td align="center" '.$cls.' >';
                       $html .= price($total[$key]);
                       $totalg[$key] += $total[$key];
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }
            $html .= '</tr>';
            
            if($data && count($data)>0){
                foreach ($data as $key => $value) {
                    $html .= '<tr>';
                        $html .= '<td class="td_vert" style="background-color:#99cc00;width:1%"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                        $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                        $html .= '<td class="td_label" style="line-height: 2;" title="'.$value['label'].'">'.$value['label'].' </td>';

                        foreach ($arr_mois as $num => $val) {
                            $cls='style="line-height: 2;"';
                            $month_current = date('m');
                            if($num == $month_current)
                                $cls ='style="background-color:#ddf8d0;line-height: 2;"';
                            $html .= '<td align="center" '.$cls.' >';
                            if($value[$num]['montant_ttc']){
                                $html .= price($value[$num]['montant_ttc']);
                                $total_ttc += $value[$num]['montant_ttc'];
                            }
                            else 
                                $html .= price(0);
                            $html .= '</td>';
                            if($num == $srch_nbmonth)
                                break;
                        }
                    $html .= '</tr>';
                }
            }

            $html .= '<tr class="trclean"><td class="td_vert" style="background-color:#99cc00"></td><td colspan="16"></td></tr>';
            
            if (!empty($conf->don->enabled))
            {
                $html .= '<tr style="background-color: #e9eaed !important;">';
                    $html .= '<td class="td_vert" style="background-color:#99cc00"></td>';
                    $html .= '<td class="td_vide"  style="background-color:#fff"></td>';
                    $html .= '<td class="td_grey" style="background-color:#eaeaea;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#eaeaea;"></td>';
                    $html .= '<td class="td_label" style="background-color:#eaeaea;line-height: 2;" title="'.$langs->trans('Donations').'">'.$langs->trans('Donations').'<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';
               
                    $sql = "SELECT p.societe as nom, MONTH(p.datedon) as month, p.firstname, p.lastname, date_format(p.datedon,'%Y-%m') as dm, sum(p.amount) as amount";
                    $sql .= " FROM ".MAIN_DB_PREFIX."don as p";
                    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."payment_donation as pe ON pe.fk_donation = p.rowid";
                    $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."c_paiement as c ON pe.fk_typepayment = c.id";
                    $sql .= " WHERE p.entity IN (".getEntity('donation').")";
                    $sql .= " AND fk_statut >= 2";
                    if (!empty($srch_year))
                    $sql .= " AND YEAR(p.datedon) = '".$srch_year."'";
                    $sql .= " GROUP BY p.societe, p.firstname, p.lastname, dm";

                    $sql .= $db->order($newsortfield, $sortorder);

                    $result = $db->query($sql);
                    $subtotal_ht = 0;
                    $subtotal_ttc = 0;
                    if ($result)
                    {
                        $numd = $db->num_rows($result);
                        $i = 0;
                        if ($numd)
                        {
                            while ($i < $numd)
                            {
                                $obj = $db->fetch_object($result);

                                $total_ttc_don[$obj->month] += $obj->amount;
                                $data_don[$obj->nom.'-'.$obj->firstname.'-'.$obj->lastname]['company']= $obj->nom;
                                $data_don[$obj->nom.'-'.$obj->firstname.'-'.$obj->lastname]['nom']= $obj->firstname.' '.$obj->lastname;
                                $data_don[$obj->nom.'-'.$obj->firstname.'-'.$obj->lastname][$obj->month]['amount']= $obj->amount;
                                $i++;
                            }   
                        }
                    }


                    foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#eaeaea;line-height: 2;"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#ddf8d0;line-height: 2;"';
                        $html .= '<td align="center" '.$cls.' >';
                           $html .= price($total_ttc_don[$key]);
                            $totalg[$key] += $total_ttc_don[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                        break;
                    }
                $html .= '</tr>';
                if($data_don && count($data_don)>0){
                    foreach ($data_don as $key => $value) {
                        $html .= '<tr>';
                            $html .= '<td class="td_vert" style="background-color:#99cc00"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff"></td>';
                            $html .= '<td class="td_grey" style="background-color:#eaeaea;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff"></td>';
                            $html .= '<td class="td_label" style="line-height: 2;" title="'.$value['company'].' '.$value['nom'].'">'.$value['company'].' '.$value['nom'].'</td>';

                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height: 2;"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#ddf8d0;line-height: 2;"';
                                $html .= '<td align="center" '.$cls.' >';
                                    if($value[$num]['amount']){
                                        $html .= price($value[$num]['amount']);
                                        $total_ttc += $value[$num]['amount'];
                                    }
                                    else 
                                        $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                break;
                            }
                        $html .= '</tr>';
                    }
                }
            }

            $html .= '<tr class="trclean"><td class="td_vert" style="background-color:#99cc00"></td><td colspan="16"></td></tr>';
            
            if($conf->tax->enabled){

                $html .= '<tr style="background-color: #e9eaed !important;">';
                    $html .= '<td class="td_vert" style="background-color:#99cc00"></td>';
                    $html .= '<td class="td_vide" style="background-color:#fff"></td>';
                    $html .= '<td class="td_grey" style="background-color:#eaeaea;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#eaeaea;"></td>';
                    $html .= '<td class="td_label" style="background-color:#eaeaea;line-height: 2;" title="'.$langs->trans('VAT').'">'.$langs->trans('VAT').'<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';
                   
                    //  TVA
                    $sql = "SELECT date_format(t.datev,'%Y-%m') as dm, MONTH(t.datev) as month, sum(t.amount) as amount";
                    $sql .= " FROM ".MAIN_DB_PREFIX."tva as t";
                    $sql .= " WHERE amount < 0";
                    if (!empty($srch_year) )
                        $sql .= " AND YEAR(t.datev) =".$srch_year;

                    $sql .= " AND t.entity = ".$conf->entity;
                    $sql .= " GROUP BY dm, month";
                    $newsortfield = $sortfield;
                    if ($newsortfield == 's.nom, s.rowid') $newsortfield = 'dm';
                    if ($newsortfield == 'amount_ht') $newsortfield = 'amount';
                    if ($newsortfield == 'amount_ttc') $newsortfield = 'amount';
                    // $sql .= $db->order($newsortfield, $sortorder);

                    dol_syslog("get vat really received back", LOG_DEBUG);
                    $result = $db->query($sql);
                    if ($result) {
                        $num = $db->num_rows($result);
                        $i = 0;
                        if ($num) {
                            while ($i < $num) {
                                $obj = $db->fetch_object($result);
                                $total_ttc_tva[$obj->month] += -$obj->amount;
                                $datatva[$i][$obj->month]['montant_ttc']=-$obj->amount;

                                $i++;
                            }
                        }
                        $db->free($result);
                    }

                    foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#eaeaea;line-height: 2;"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#ddf8d0;line-height:2;width:7%"';

                        $html .= '<td align="center" '.$cls.'>';
                           $html .= price($total_ttc_tva[$key]);
                           $totalg[$key] += $total_ttc_tva[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                            break;
                    }
                $html .= '</tr>';
                if($datatva && count($datatva)>0){
                    foreach ($datatva as $key => $value) {
                        $html .= '<tr>';
                            $html .= '<td class="td_vert" style="background-color:#99cc00"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;"></td>';
                            $html .= '<td class="td_grey" style="background-color:#eaeaea;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;"></td>';
                            $html .= '<td class="td_label" style="line-height: 2;"  title="'.$langs->trans('VATCollected').'">'.$langs->trans('VATCollected').'</td>';

                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height: 2;"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#ddf8d0;line-height:2;width:7%;"';
                                $html .= '<td align="center" '.$cls.' >';
                                    if($value[$num]['montant_ttc']){
                                        $html .= price($value[$num]['montant_ttc']);
                                        $total_ttc += $value[$num]['montant_ttc'];
                                    }
                                    else 
                                        $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                break;
                            }
                        $html .= '</tr>';
                    }
                }
            }

            $html .= '<tr class="trclean"><td class="td_vert" style="background-color:#99cc00"></td><td colspan="16"></td></tr>';

            $html .= '<tr class="liste_total">';
                $html .= '<td colspan="5" style="background-color:#99cc00;line-height:2">  '.$langs->trans("Total").'</td>';
                 foreach ($arr_mois as $key => $value) {
                    $cls='';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='td_curent';
                    $html .= '<td style=" background-color: #99cc00;line-height:2;width:7%;" align="center">';
                        $html .= price($totalg[$key]);
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }
            $html .= '</tr>';
        $html .= '</table>';
    $html .= '</div>';
    
    $html .= '<div id="depenses">';
        $html .= '<table  cellpadding="0px" cellspacing="0" width="100%">';
            $html .= '<input type="hidden" name="action" value="generer">';
            
            $html .= '<tr>';
                $html .= '<td class="td_vert" style="background-color:#f38400;width:1%"></td>';
                $html .= '<td class="td_vert" style="background-color:#f38400;width:1%"></td>';
                $html .= '<td class="td_vert" style="background-color:#f38400;width:1%"></td>';
                $html .= '<td class="td_vert" style="background-color:#f38400;width:1%"></td>';
                $html .= '<td colspan="" style="background-color:#f38400;color:white;width:11%;line-height: 2;" align="left">'.$langs->trans("Income").'</td>';
                foreach ($arr_mois as $key => $value) {
                    $cls='style="background-color: #dadbdd;line-height:2;width:7%;"';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='style="background-color: #f38400;line-height:2;width:7%;" ';
                    $html .= '<td '.$cls.' align="center">';
                        $html .= $value;
                    $html .= '</td>';
                    if($key == $srch_nbmonth){
                        break;
                    }
                }
            $html .= '</tr>';
            $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';
            
            $html .= '<tr>';
                $html .= '<td class="td_orang" style="background-color: #f38400;width:1%"></td>';
                $html .= '<td class="td_vide" style="background-color: #fff;width:1%;"></td>';
                $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                $html .= '<td class="td_label" style="background-color:#e9eaed;line-height: 2;width:11%" title="'.$langs->trans('SuppliersInvoices').'">'.$langs->trans('SuppliersInvoices').'<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';
               
                $sql = "SELECT s.nom as name, s.rowid as socid, sum(pf.amount) as amount_ttc, MONTH(p.datep) as month";
                $sql .= " FROM ".MAIN_DB_PREFIX."paiementfourn as p";
                $sql .= ", ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf";
                $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."facture_fourn as f";
                $sql .= " ON pf.fk_facturefourn = f.rowid";
                $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."societe as s";
                $sql .= " ON f.fk_soc = s.rowid";
                $sql .= " WHERE p.rowid = pf.fk_paiementfourn ";

                if (!empty($srch_year)){
                    $sql .= " AND YEAR(p.datep) =".$srch_year;
                }
                $sql .= " AND f.entity IN (".getEntity('invoice').")";
                if ($socid) $sql .= " AND f.fk_soc = ".$socid;
                $sql .= " GROUP BY name, socid, month";
                $sql .= $db->order($sortfield, $sortorder);
                dol_syslog("get customer invoices", LOG_DEBUG);
                $result = $db->query($sql);
                if ($result) {
                    $num = $db->num_rows($result);
                    $i = 0;
                    while ($i < $num)
                    {
                        $objp = $db->fetch_object($result);
                        $data_soc[$objp->socid][$objp->month]['montant_ttc'] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
                        $data_soc[$objp->socid]['label'] = $objp->name;
                        $total_soc[$objp->month] += (isset($objp->amount_ttc) ? $objp->amount_ttc : 0);
                        $i++;
                    }
                    $db->free($result);
                } 

                foreach ($arr_mois as $key => $value) {
                    $cls='style="background-color:#eaeaea;line-height:2;width:7%;"';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                    $html .= '<td align="center" '.$cls.' >';
                       $html .= price($total_soc[$key]);
                       $totalg_depens[$key] += $total_soc[$key];
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }

            $html .= '</tr>';
            if($data_soc && count($data_soc)>0){
                foreach ($data_soc as $key => $value) {
                    $html .= '<tr>';
                        $html .= '<td style=" background-color: #f38400;width:1%;line-height:2"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;width:1%;line-height:2"></td>';
                        $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%;line-height:2"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;width:1%;line-height:2"></td>';
                        $html .= '<td class="td_label" style="line-height:2;width:11%" title="'.$value['label'].'">'.$value['label'].'</td>';

                        foreach ($arr_mois as $num => $val) {
                            $cls='style="line-height:2;width:7%"';
                            $month_current = date('m');
                            if($num == $month_current)
                                $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                            $html .= '<td align="center" '.$cls.' >';
                            if($value[$num]['montant_ttc']){
                                $html .= price($value[$num]['montant_ttc']);
                                $total_ttc += $value[$num]['montant_ttc'];
                            }
                            else 
                                $html .= price(0);
                            $html .= '</td>';
                            if($num == $srch_nbmonth)
                                break;
                        }
                    $html .= '</tr>';
                }
            }

            $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';

            $html .= '<tr>';
                $html .= '<td class="td_orang" style="background-color: #f38400;width:1%"></td>';
                $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%;"></td>';
                $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%;"></td>';
                $html .= '<td class="td_label" style="background-color:#e9eaed;line-height: 2;width:11%" title="'.$langs->trans("SocialContributionsNondeductibles").'">'.$langs->trans("SocialContributionsNondeductibles").'<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';

                $sql = "SELECT cs.rowid as rowid, c.id, c.libelle as label, sum(p.amount) as amount, MONTH(p.datep) as month";
                $sql .= " FROM ".MAIN_DB_PREFIX."c_chargesociales as c";
                $sql .= ", ".MAIN_DB_PREFIX."chargesociales as cs";
                $sql .= ", ".MAIN_DB_PREFIX."paiementcharge as p";
                $sql .= " WHERE p.fk_charge = cs.rowid";
                $sql .= " AND cs.fk_type = c.id";
                $sql .= " AND c.deductible = 0";

                if (!empty($srch_year)){
                    $sql .= " AND YEAR(p.datep) =".$srch_year;
                }

                $sql .= " AND cs.entity = ".$conf->entity;
                $sql .= " GROUP BY c.libelle, c.id, month";
                dol_syslog("get social contributions deductible=1", LOG_DEBUG);
                $result = $db->query($sql);
                $subtotal_ht = 0;
                $subtotal_ttc = 0;
                if ($result) {
                    $num = $db->num_rows($result);
                    $i = 0;
                    if ($num) {
                        while ($i < $num) {
                            $obj = $db->fetch_object($result);

                            $total_ht -= $obj->amount;
                            $total_ttc -= $obj->amount;
                            $subtotal_ht += $obj->amount;
                            $subtotal_ttc += $obj->amount;


                            $data_chargesocial2[$obj->rowid][$obj->month]['amount_ttc'] = -$obj->amount;
                            $data_chargesocial2[$obj->rowid]['label'] = $obj->label;
                            $total_ttc_charg2[$obj->month] += -$obj->amount;
                            $i++;
                        }
                    }
                }
                foreach ($arr_mois as $key => $value) {
                    $cls='style="background-color:#eaeaea;line-height:2;width:7%;"';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                    $html .= '<td align="center" '.$cls.' >';
                       $html .= price(-$total_ttc_charg2[$key]);
                       $totalg_depens[$key] += -$total_ttc_charg2[$key];
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }

            $html .= '</tr>';
            if($data_chargesocial2 && count($data_chargesocial2)>0){
                foreach ($data_chargesocial2 as $key => $value) {
                    $html .= '<tr>';
                        $html .= '<td style=" background-color: #f38400;width:1%;"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                        $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%;"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                        $html .= '<td class="td_label" slyle="line-height:2; width:11%;" title="'.$value['label'].'">'.$value['label'].'</td>';

                        foreach ($arr_mois as $num => $val) {
                            $cls='style="line-height:2;width:7%;"';
                            $month_current = date('m');
                            if($num == $month_current)
                                $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                            $html .= '<td align="center" '.$cls.' >';
                            if($value[$num]['amount_ttc']){
                                $html .= price(-$value[$num]['amount_ttc']);
                            }
                            else 
                                $html .= price(0);
                            $html .= '</td>';
                            if($num == $srch_nbmonth)
                                break;
                        }
                    $html .= '</tr>';
                }
            }

            $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';

            $html .= '<tr>';
                $html .= '<td style=" background-color: #f38400;width:1%;"></td>';
                $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                $html .= '<td class="td_label" style="background-color:#e9eaed;line-height:2;width:11%" title="'.$langs->trans("SocialContributionsDeductibles").'">'.$langs->trans("SocialContributionsDeductibles").'<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';

                $sql = "SELECT cs.rowid as rowid, c.id, c.libelle as label, sum(p.amount) as amount, MONTH(p.datep) as month";
                $sql .= " FROM ".MAIN_DB_PREFIX."c_chargesociales as c";
                $sql .= ", ".MAIN_DB_PREFIX."chargesociales as cs";
                $sql .= ", ".MAIN_DB_PREFIX."paiementcharge as p";
                $sql .= " WHERE p.fk_charge = cs.rowid";
                $sql .= " AND cs.fk_type = c.id";
                $sql .= " AND c.deductible = 1";

                if (!empty($srch_year)){
                    $sql .= " AND YEAR(p.datep) =".$srch_year;
                }

                $sql .= " AND cs.entity = ".$conf->entity;
                $sql .= " GROUP BY c.libelle, c.id, month";
                // $newsortfield = $sortfield;
                // if ($newsortfield == 's.nom, s.rowid') $newsortfield = 'c.libelle, c.id';
                // if ($newsortfield == 'amount_ht') $newsortfield = 'amount';
                // if ($newsortfield == 'amount_ttc') $newsortfield = 'amount';
                // $sql .= $db->order($newsortfield, $sortorder);
                dol_syslog("get social contributions deductible=1", LOG_DEBUG);
                $result = $db->query($sql);
                $subtotal_ht = 0;
                $subtotal_ttc = 0;
                if ($result) {
                    $num = $db->num_rows($result);
                    $i = 0;
                    if ($num) {
                        while ($i < $num) {
                            $obj = $db->fetch_object($result);

                            $total_ht -= $obj->amount;
                            $total_ttc -= $obj->amount;
                            $subtotal_ht += $obj->amount;
                            $subtotal_ttc += $obj->amount;


                            $data_chargesocial[$obj->rowid][$obj->month]['amount_ttc'] = -$obj->amount;
                            $data_chargesocial[$obj->rowid]['label'] = $obj->label;
                            $total_ttc_charg[$obj->month] += -$obj->amount;
                            $i++;
                        }
                    }
                }
                foreach ($arr_mois as $key => $value) {
                    $cls='style="background-color:#eaeaea;line-height:2;width:7%;"';
                    $month_current = date('m');
                    if($key == $month_current)
                        $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                    $html .= '<td align="center" '.$cls.' >';
                       $html .= price(-$total_ttc_charg[$key]);
                       $totalg_depens[$key] += -$total_ttc_charg[$key];
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }
            $html .= '</tr>';

            if($data_chargesocial && count($data_chargesocial)>0){
                foreach ($data_chargesocial as $key => $value) {
                    $html .= '<tr>';
                        $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;;width:1%"></td>';
                        $html .= '<td class="td_grey" style="background-color:#eaeaea;;width:1%;line-height2;"></td>';
                        $html .= '<td class="td_vide" style="background-color:#fff;;width:1%"></td>';
                        $html .= '<td class="td_label" style="line-height:2;width:11%" title="'.$value['label'].'">'.$value['label'].'</td>';

                        foreach ($arr_mois as $num => $val) {
                            $cls='style="line-height:2;width:7%;"';
                            $month_current = date('m');
                            if($num == $month_current)
                                $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                            $html .= '<td align="center" '.$cls.' >';
                            if($value[$num]['amount_ttc']){
                                $html .= price(-$value[$num]['amount_ttc']);
                            }
                            else 
                                $html .= price(0);
                            $html .= '</td>';
                            if($num == $srch_nbmonth)
                                break;
                        }
                    $html .= '</tr>';
                }
            }
          
            $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';


            if (!empty($conf->salaries->enabled))
            {

                $html .= '<tr>';
                    $html .= '<td style=" background-color: #f38400;width:1%;"></td>';
                    $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                    $html .= '<td class="td_label" style="background-color:#e9eaed;line-height:2;width:11%" title="'.$langs->trans("Salaries").'">'.$langs->trans("Salaries").'<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span></td>';

                    $sql = "SELECT u.rowid, u.firstname, u.lastname, p.fk_user, p.label as label, MONTH(p.datep) as month, date_format(p.datep,'%Y-%m') as dm, sum(p.amount) as amount";
                    $sql .= " FROM ".MAIN_DB_PREFIX."payment_salary as p";
                    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."user as u ON u.rowid=p.fk_user";
                    $sql .= " WHERE p.entity IN (".getEntity('payment_salary').")";
                    if (!empty($srch_year) )
                        $sql .= " AND YEAR(p.datep) = ".$srch_year;

                    $sql .= " GROUP BY u.rowid, u.firstname, u.lastname, p.fk_user, p.label, dm, month";
                    $newsortfield = $sortfield;
                    if ($newsortfield == 's.nom, s.rowid') $newsortfield = 'u.firstname, u.lastname';
                    if ($newsortfield == 'amount_ht') $newsortfield = 'amount';
                    if ($newsortfield == 'amount_ttc') $newsortfield = 'amount';
                    // $sql .= $db->order($newsortfield, $sortorder);
                    $result = $db->query($sql);
                    if ($result)
                    {
                        $num = $db->num_rows($result);
                        $i = 0;
                        if ($num)
                        {
                            while ($i < $num)
                            {
                                $obj = $db->fetch_object($result);

                                $total_ht -= $obj->amount;
                                $total_ttc_salair[$obj->month] -= $obj->amount;
                                $subtotal_ht += $obj->amount;
                                $subtotal_ttc += $obj->amount;

                                $data_salaire[$obj->rowid][$obj->month]['amount_ttc'] = -$obj->amount;
                                $data_salaire[$obj->rowid]['label'] = $obj->firstname." ".$obj->lastname;
                                $i++;
                            }
                        }
                    }
                     foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#e9eaed;line-height:2;width:7%;"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                        $html .= '<td align="center" '.$cls.' >';
                           $html .= price(-$total_ttc_salair[$key]);
                           $totalg_depens[$key] += -$total_ttc_salair[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                            break;
                    }

                $html .= '</tr>';
                if($data_salaire && count($data_salaire)>0){
                    foreach ($data_salaire as $key => $value) {
                        $html .= '<tr>';
                            $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                            $html .= '<td class="td_grey" style="background-color:#eaeaea;;width:1%"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                            $html .= '<td class="td_label" style="line-height:2;width:11%" title="'.$value['label'].'">'.$value['label'].'</td>';

                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height:2;width:7%;"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                                $html .= '<td align="center" '.$cls.' >';
                                if($value[$num]['amount_ttc']){
                                    $html .= price(-$value[$num]['amount_ttc']);
                                    $totalg2[$num] += $value[$num]['amount_ttc'];
                                }
                                else 
                                    $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                    break;
                            }
                        $html .= '</tr>';
                    }
                }
                $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';
            }


            if (!empty($conf->expensereport->enabled))
            {

                $html .= '<tr style="background-color: #e9eaed;width:1%">';
                    $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                    $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';

                    $sql = "SELECT p.rowid, p.ref, u.rowid as userid, u.firstname, u.lastname, date_format(pe.datep,'%Y-%m') as dm, sum(p.total_ht) as amount_ht, sum(p.total_ttc) as amount_ttc, MONTH(pe.datep) as month";
                    $sql .= " FROM ".MAIN_DB_PREFIX."expensereport as p";
                    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."user as u ON u.rowid=p.fk_user_author";
                    $sql .= " INNER JOIN ".MAIN_DB_PREFIX."payment_expensereport as pe ON pe.fk_expensereport = p.rowid";
                    $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."c_paiement as c ON pe.fk_typepayment = c.id";
                    $sql .= " WHERE p.entity IN (".getEntity('expensereport').")";
                    $sql .= " AND p.fk_statut>=5";

                    if (!empty($srch_year) )
                    {
                        $sql .= " AND YEAR(pe.datep) =".$srch_year;
                    }

                    $sql .= " GROUP BY u.rowid, p.rowid, p.ref, u.firstname, u.lastname, dm, month";
                    $result = $db->query($sql);
                    $html .= '<td class="td_label" style="background-color:#e9eaed;line-height:2;width:11%;" title="'.$langs->trans("ExpenseReport").'">'.$langs->trans("ExpenseReport");
                        if ($result)
                        {
                            $num = $db->num_rows($result);
                            $i = 0;
                            if($num > 1)
                            $html .= '<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span>';
                            if ($num)
                            {
                                while ($i < $num)
                                {
                                    $obj = $db->fetch_object($result);

                                    $total_ht -= $obj->amount_ttc;
                                    $total_ttc_expens[$obj->month] -= $obj->amount_ttc;
                                    $subtotal_ht += $obj->amount_ttc;
                                    $subtotal_ttc += $obj->amount_ttc;

                                    $data_expens[$obj->rowid][$obj->month]['amount_ttc'] = -$obj->amount_ttc;
                                    $data_expens[$obj->rowid]['label'] = $obj->firstname." ".$obj->lastname;
                                    $data_expens[$obj->rowid]['userid'] = $obj->userid;
                                    $i++;
                                }
                            }
                        }
                    $html .= '</td>';
                    foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#e9eaed;line-height:2;width:7%;"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                        $html .= '<td align="center" '.$cls.' >';
                           $html .= price(-$total_ttc_expens[$key]);
                           $totalg_depens[$key] += -$total_ttc_expens[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                            break;
                    }
                   
                $html .= '</tr>';
                if($data_expens && count($data_expens)>0){

                    foreach ($data_expens as $key => $value) {
                         $html .= '<tr>';
                            $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                            $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                            $html .= '<td class="td_label" style="width:11%;line-height:2;width:11%;" title="'.$value['label'].'">'.$value['label'].'</td>';
                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height:2;width:7%;"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#fbd4a1;line-height:2;width:7%;"';
                                $html .= '<td align="center" '.$cls.' >';
                                if($value[$num]['amount_ttc']){
                                    $html .= price(-$value[$num]['amount_ttc']);
                                }
                                else 
                                    $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                    break;
                            }
                        $html .= '</tr>';
                    }
                }

                  

                $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';
            }

            if (!empty($conf->global->ACCOUNTING_REPORTS_INCLUDE_VARPAY)){

                $html .= '<tr>';
                    $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                    $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%"></td>';
                    $html .= '<td class="td_label" style="background-color:#e9eaed;line-height:2;width:11%;" title="'.$langs->trans("VariousPayment").'">'.$langs->trans("VariousPayment");

                        $sql = "SELECT SUM(p.amount) AS amount, MONTH(p.datep) as month FROM ".MAIN_DB_PREFIX."payment_various as p";
                        $sql .= ' WHERE p.entity IN ('.getEntity('payment_various');
                        
                        if (!empty($srch_year) )
                            $sql .= " AND YEAR(p.datep) =".$srch_year;

                        $sql .= ' GROUP BY p.sens, month';
                        $sql .= ' ORDER BY p.sens';

                        dol_syslog('get various payments', LOG_DEBUG);
                        $result = $db->query($sql);
                        if ($result)
                        {
                            // Debit
                            $obj = $db->fetch_object($result);
                            $num = $db->num_rows($result);
                            $i = 0;
                            $html .= '<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span>';
                            if ($num)
                            {
                                while ($i < $num)
                                {
                                    $total_ttc_varpay[$obj->month] -= $obj->amount;
                                    $data_varpay[$obj->rowid][$obj->month]['amount_ttc'] = -$obj->amount;
                                    $i++;
                                }
                            }
                        }
                    $html .= '</td>';
                    foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#e9eaed;line-height:2;width:7%"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                        $html .= '<td align="center" '.$cls.' >';
                           $html .= price(-$total_ttc_varpay[$key]);
                           $totalg_depens[$key] += -$total_ttc_varpay[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                            break;
                    }
                   
                $html .= '</tr>';
                if($data_varpay && count($data_varpay)>0){

                    foreach ($data_varpay as $key => $value) {
                         $html .= '<tr>';
                            $html .= '<td style=" background-color: #f38400;width:1%;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;"></td>';
                            $html .= '<td class="td_grey" style="background-color:#e9eaed;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;"></td>';
                            $html .= '<td class="td_label" style="line-height:2;width:11%;" title="'.$langs->trans("Debit").'">'.$langs->trans("Debit").'</td>';
                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height:2;width:7%"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                                $html .= '<td align="center" '.$cls.' >';
                                    if($value[$num]['amount_ttc'])
                                        $html .= price(-$value[$num]['amount_ttc']);
                                    else 
                                        $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                    break;
                            }
                        $html .= '</tr>';
                    }
                }
                $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';
            }


            if (!empty($conf->global->ACCOUNTING_REPORTS_INCLUDE_LOAN) && !empty($conf->loan->enabled)){

                $html .= '<tr>';
                    $html .= '<td style=" background-color: #f38400;width:1%;"></td>';
                    $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                    $html .= '<td class="td_grey" style="background-color:#e9eaed;width:1%;"></td>';
                    $html .= '<td class="td_label" style="background-color:#e9eaed;line-height:2;width:11%;" title="'.$langs->trans("PaymentLoan").'">'.$langs->trans("PaymentLoan");

                    $sql = 'SELECT l.rowid as id, l.label AS label, SUM(p.amount_capital + p.amount_insurance + p.amount_interest) as amount, MONTH(p.datep) as month FROM '.MAIN_DB_PREFIX.'payment_loan as p';
                    $sql .= ' LEFT JOIN '.MAIN_DB_PREFIX.'loan AS l ON l.rowid = p.fk_loan';
                    $sql .= ' WHERE 1 = 1';

                    if (!empty($srch_year) )
                        $sql .= " AND YEAR(p.datep) =".$srch_year;

                    $sql .= ' GROUP BY p.fk_loan, month ';
                    $sql .= ' ORDER BY p.fk_loan';
                    $result = $db->query($sql);
                    if ($result)
                    {
                        $num = $db->num_rows($result);
                            $html .= '<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span>';
                        if ($num)
                        {
                            while ($obj = $db->fetch_object($result))
                            {

                                $total_ttc_loan[$obj->month] -= $obj->amount;

                                $data_loan[$obj->rowid][$obj->month]['amount_ttc'] = -$obj->amount;
                                $data_loan[$obj->rowid]['label'] = $obj->label;
                                $data_loan[$obj->rowid]['id'] = $obj->id;
                            }
                        }
                    }
                    $html .= '</td>';
                    foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#e9eaed;line-height:2;width:7%;"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                        $html .= '<td align="center" '.$cls.' >';
                           $html .= price(-$total_ttc_loan[$key]);
                           $totalg_depens[$key] += -$total_ttc_loan[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                            break;
                    }
                   
                $html .= '</tr>';

                if($data_loan && count($data_loan)>0){
                    require_once DOL_DOCUMENT_ROOT.'/loan/class/loan.class.php';
                    $loan_static = new Loan($db);
                    foreach ($data_loan as $key => $value) {
                        $html .= '<tr>';
                            $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                            $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                            $loan_static->id = $value["id"];
                            $loan_static->ref = $value["id"];
                            $loan_static->label = $value["label"];
                            $html .= '<td class="td_label" style="line-height:2;width:11%;" title="'.$value['label'].'">'.$loan_static->ref.' - '.$value['label'].'</td>';

                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height:2;width:7%;"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                                $html .= '<td align="center" '.$cls.' >';
                                if($value[$num]['amount_ttc']){
                                    $html .= price(-$value[$num]['amount_ttc']);
                                }
                                else 
                                    $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                    break;
                            }
                        $html .= '</tr>';
                    }
                }

                  

                $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';

            }


            if (!empty($conf->tax->enabled )){

                $html .= '<tr style="background-color: #e9eaed !important;">';
                    $html .= '<td style=" background-color: #f38400;width:1%"></td>';
                    $html .= '<td class="td_vide" style="background-color:#fff;width:1%"></td>';
                    $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%"></td>';
                    $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%"></td>';
                    $html .= '<td class="td_label" style="background-color:#e9eaed;line-height:2;width:11%;" title="'.$langs->trans("VAT").'">'.$langs->trans("VAT");
                        $html .= '<span class="show_lign" onclick="showhide_lign(this)"><i class="fa fa-angle-double-down"></i></span>';
                    $html .= '</td>';

                    $sql = "SELECT date_format(t.datev,'%Y-%m') as dm, sum(t.amount) as amount, MONTH(t.datev) as month";
                    $sql .= " FROM ".MAIN_DB_PREFIX."tva as t";
                    $sql .= " WHERE amount > 0";
                    if (!empty($srch_year))
                        $sql .= " AND YEAR(t.datev) = ".$srch_year;
                    $sql .= " AND t.entity = ".$conf->entity;
                    $sql .= " GROUP BY dm, month";
                    // $newsortfield = $sortfield;
                    // if ($newsortfield == 's.nom, s.rowid') $newsortfield = 'dm';
                    // if ($newsortfield == 'amount_ht') $newsortfield = 'amount';
                    // if ($newsortfield == 'amount_ttc') $newsortfield = 'amount';
                    // $sql .= $db->order($newsortfield, $sortorder);

                    dol_syslog("get vat really paid", LOG_DEBUG);
                    $result = $db->query($sql);
                    if ($result) {
                        $num = $db->num_rows($result);
                        $i = 0;
                        if ($num) {
                            while ($i < $num) {
                                $obj = $db->fetch_object($result);
                                $total_ttc_tvapay[$obj->month] -= $obj->amount;
                                $data_tvapay[$i][$obj->month]['amount_ttc'] = -$obj->amount;
                                $i++;
                            }
                        }
                    }
                    foreach ($arr_mois as $key => $value) {
                        $cls='style="background-color:#e9eaed;line-height:2;width:7%;"';
                        $month_current = date('m');
                        if($key == $month_current)
                            $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                        $html .= '<td align="center" '.$cls.' >';
                           $html .= price(-$total_ttc_tvapay[$key]);
                           $totalg_depens[$key] += -$total_ttc_tvapay[$key];
                        $html .= '</td>';
                        if($key == $srch_nbmonth)
                            break;
                    }
                   
                $html .= '</tr>';
                if($data_tvapay && count($data_tvapay)>0){
                    require_once DOL_DOCUMENT_ROOT.'/loan/class/loan.class.php';
                    $loan_static = new Loan($db);
                    foreach ($data_tvapay as $key => $value) {
                        $html .= '<tr>';
                            $html .= '<td style=" background-color: #f38400;width:1%;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                            $html .= '<td class="td_grey" style="background-color:#eaeaea;width:1%;"></td>';
                            $html .= '<td class="td_vide" style="background-color:#fff;width:1%;"></td>';
                            $html .= '<td class="td_label" title="'.$langs->trans("VATPaid").'">'.$langs->trans("VATPaid").'</td>';

                            foreach ($arr_mois as $num => $val) {
                                $cls='style="line-height:2;width:7%"';
                                $month_current = date('m');
                                if($num == $month_current)
                                    $cls ='style="background-color:#fbd4a1;line-height:2;width:7%"';
                                $html .= '<td align="center" '.$cls.' >';
                                if($value[$num]['amount_ttc']){
                                    $html .= price(-$value[$num]['amount_ttc']);
                                }
                                else 
                                    $html .= price(0);
                                $html .= '</td>';
                                if($num == $srch_nbmonth)
                                    break;
                            }
                        $html .= '</tr>';
                    }
                }

                  

                $html .= '<tr class="trclean"><td style=" background-color: #f38400;"></td><td colspan="16"></td></tr>';
            }

            $html .= '<tr class="liste_total">';
                $html .= '<td colspan="5" style="background-color:#f38400;line-height:2;color:#fff;">  '.$langs->trans("Total").'</td>';
                foreach ($arr_mois as $key => $value) {
                    $cls='';
                    $month_current = date('m');
                    if($key == $month_current)
                       $cls ='';
                    $html .= '<td style="background-color:#f38400;line-height:2;color:#fff;" align="center" >';
                        $html .= price($totalg_depens[$key]);
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }
            $html .= '</tr>';
            $html .= '<tr class="trclean"><td></td><td colspan="16"></td></tr>';

            $html .= '<tr>';
                $html .= '<td colspan="5" style="background-color: #dadbdd;line-height:2;">  '.$langs->trans("Total_tresorerie").'</td>';
                foreach ($arr_mois as $key => $value) {
                    $html .= '<td align="center" style="background-color: #dadbdd;line-height:2;">';
                        $numtotal = $totalg[$key]-$totalg_depens[$key];
                        $html .= price($numtotal);
                    $html .= '</td>';
                    if($key == $srch_nbmonth)
                        break;
                }
            $html .= '</tr>';
        $html .= '</table>';
    $html .= '</div>';

$html .= '</div>';

$html .='<style>';
    $html .='#EtatTresorerie .td_grey{
        background-color: #eaeaea;
        padding: 7px;
    }

    #EtatTresorerie .td_vide {
        background-color: #fff;
        border: 0px;
        padding: 7px;
    }

    #EtatTresorerie .td_vert {
        padding: 7px;
        background-color: #99cc00;
        color: #fff;
        border: 0px;
    }

    #EtatTresorerie .td_vert_curent{
        color: #fff;
        font-weight: bold;
        border-top: 1px solid #a9c390;
        border-right: 1px solid #a9c390;
        border-bottom: 1px solid #a9c390;
        border-left: 1px solid #bbdbf5;
        background-color: #99cc00;
    }

    #revenus .liste_total td{
        background-color: #99cc00;
    }

    #EtatTresorerie .td_curent{
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        border-left: 1px solid #ccc;
        background-color: #ddf8d0;
        padding: 0.2em 0.4em 0.2em 0.2em;
        color: #333;
    }

    #EtatTresorerie .td_orang {
        padding: 7px;
        background-color: #f38400;
        color: #fff;
        border: 0px;
    }

    #EtatTresorerie .td_orang_curent{
        color: #fff;
        font-weight: bold;
        border-top: 1px solid #a9c390;
        border-right: 1px solid #a9c390;
        border-bottom: 1px solid #a9c390;
        border-left: 1px solid #bbdbf5;
        background-color: #f38400;
    }

    #depenses .liste_total td{
        background-color: #f38400;
    }

    #depenses .td_curent{
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        border-left: 1px solid #ccc;
        background-color: #fbd4a1;
        padding: 0.2em 0.4em 0.2em 0.2em;
        color: #333;
    }

    #EtatTresorerie .trclean{
        background-color: #fff !important;
    }

    #EtatTresorerie table:first-child{
        border-top: 0px !important; 
    }

    #EtatTresorerie .td_label{
        width: 130px;
        max-width: 130px !important;
        /*text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;*/
    }
    #EtatTresorerie .trclean td{
        border:0px !important;
    }

    #EtatTresorerie tr.liste_total td{
        color: #fff !important;
    }

    #EtatTresorerie .hide_lign{
    }

    #EtatTresorerie .td_label span.show_lign, #EtatTresorerie .td_label span.hide_lign{
        font-size: 12px;
        float: right;
        cursor: pointer;
        color: #696969;
        line-height: 1.7;
    }

    #EtatTresorerie tr.lign_total{
        background-color: #e9eaed !important;
    }

    #EtatTresorerie #revenus tr.liste_titre, #EtatTresorerie #depenses tr.liste_titre{
        background-color: #dadbdd !important;
    }

    #EtatTresorerie tr.lignes_show{
        display: table-row;
    }

    #EtatTresorerie tr.lignes_hide{
        display: none;
    }

    #EtatTresorerie #revenus tr.liste_titre td.td_vide {
        color: #fff !important;
        background-color: #99cc00 !important;
        font-weight: bold;
    }
    #EtatTresorerie #depenses tr.liste_titre td.td_vide {
        color: #fff !important;
        background-color: #f38400 !important;
        font-weight: bold;
    }';
$html .='</style>';
