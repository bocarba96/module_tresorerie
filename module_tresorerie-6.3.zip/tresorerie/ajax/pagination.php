<?php

if (!defined('NOREQUIRESOC'))    define('NOREQUIRESOC', 1);
if (!defined('NOCSRFCHECK'))     define('NOCSRFCHECK', 1);
if (!defined('NOTOKENRENEWAL'))  define('NOTOKENRENEWAL', 1);
if (!defined('NOREQUIREHTML'))   define('NOREQUIREHTML', 1);
if (!defined('NOREQUIREAJAX'))   define('NOREQUIREAJAX', 1);

$res=0;
if (! $res && file_exists("../../main.inc.php")) $res=@include("../../main.inc.php");       // For root directory
if (! $res && file_exists("../../../main.inc.php")) $res=@include("../../../main.inc.php"); // For "custom" 

require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';

dol_include_once("/tresorerie/class/tresorerie.class.php");

global $langs, $conf, $user;

$langs->loadLangs(array('bills', 'companies', 'compta', 'products', 'banks', 'main', 'withdrawals'));

$tresorerie = new tresorerie($db);


/*
 * View
 */

//init var
$sql = GETPOST('sql');
$topage = GETPOST('topage');
$nb_lign = GETPOST('nb_lign');
$action = GETPOST('action');
$nb_month = GETPOST('nb_month');
$year = GETPOST('year');
$color = GETPOST('color');
$element = GETPOST('id_element');
$html = '';

$arr_mois = monthArray($langs,$topage);
$arr_nbday = [1=>31,2=>28,3=>31,4=>30,5=>31,6=>30,7=>31,8=>31,9=>30,10=>31,11=>30,12=>31];

$result = $tresorerie->getData($sql,$topage,$nb_lign);

if($result['error']){
	$html .= '<tr class="lignes_hide '.$element.'">';
	$html .= '<td class="td_'.$color.'"></td>';
    $html .= '<td class="td_vide"></td>';
	$html .= '<td class="td_label" colspan="13">'.$result['error'].'</td>';
    $html .= '</tr>';
	$json = ['error'=> $html];
}

$pagination=$tresorerie->PaginationJs($topage, $_SERVER["PHP_SELF"], $param, $result['num'], $result['numt'], $element,$nb_lign);
$htmlpagination = '<tr class="tr-pagination"><td class="td_'.$color.'"></td><td colspan="16">'.$pagination.'</td></tr>';
if($result['data'] && count($result['data'])>0){
    foreach ($result['data'] as $key => $dt) {
    	if($dt && count($dt)>0)
	    	foreach ($dt as $key => $value) {
	            $data[$value->rowkey][$value->month]['montant_ttc'] += (isset($value->amount_ttc) ? $value->amount_ttc : 0);
	            $data[$value->rowkey]['label'] = $value->label;
	            $total[$value->month] += (isset($value->amount_ttc) ? $value->amount_ttc : 0);
	    	}
    }
}
if($data && count($data)>0){
	foreach ($data as $key => $value) {
	    $html .= '<tr class="lignes_hide '.$element.'">';
	        $html .= '<td class="td_'.$color.'"></td>';
	        $html .= '<td class="td_vide"></td>';
	        $html .= '<td class="td_grey"></td>';
	        if($value['label']) $label = $value['label'];
	        // if($element == 'lign_tvadepens') $label = $langs->trans('VATCollected');
	        $html .= '<td class="td_label" colspan="2" title="'.$label.'">'.$label.' </td>';

	        foreach ($arr_mois as $num => $val) {
	            $cls='';
	            $month_current = date('m');
	            if($num == $month_current && $year == date('Y'))
	                $cls ='td_curent';
	            $html .= '<td align="center" class="td-amount '.$cls.'">';
	            if($value[$num]['montant_ttc']){
	                $html .= price($value[$num]['montant_ttc']);
	                $total_ttc += $value[$num]['montant_ttc'];
	            }
	            else 
	                $html .= price(0);
	            $html .= '</td>';
	            if($num == $nb_month)
	                break;
	        }
	    $html .= '</tr>';
	}
}
$json = ['element'=>$html, 'pagination'=>$htmlpagination];

echo json_encode($json);