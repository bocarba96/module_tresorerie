<?php

if (!defined('NOREQUIRESOC'))   define('NOREQUIRESOC', '1');
if (!defined('NOCSRFCHECK'))    define('NOCSRFCHECK', '1');
if (!defined('NOTOKENRENEWAL')) define('NOTOKENRENEWAL', '1');
if (!defined('NOREQUIREMENU'))  define('NOREQUIREMENU', '1'); // If there is no menu to show
if (!defined('NOREQUIREHTML'))  define('NOREQUIREHTML', '1'); // If we don't need to load the html.form.class.php

$res=0;
if (! $res && file_exists("../../main.inc.php")) $res=@include("../../main.inc.php");       // For root directory
if (! $res && file_exists("../../../main.inc.php")) $res=@include("../../../main.inc.php"); // For "custom" 

require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

dol_include_once("/tresorerie/class/tresorerie.class.php");

global $langs, $conf, $user;
$langs->loadLangs(array('products', 'other'));
$tresorerie = new tresorerie($db);

/*
 * View
 */

//init var
$socid = GETPOST('socid', 'int');
$factid = GETPOST('factid', 'int');
$action = GETPOST('action');


if($socid && $action == 'getfacture'){
	$data_fact=$tresorerie->InvoiceClients($socid);
	echo $data_fact;
	die();
}
if($factid && $action == 'getlineprocuct'){
	$facture = new Facture($db);
	$facture->fetch($factid);
	$facture->fetch_lines();
	print_r($facture->lines);
	die();	
}
// $amountPayment = $_POST['amountPayment'];
// $amounts = $_POST['amounts']; // from text inputs : invoice amount payment (check required)
// $remains = $_POST['remains']; // from dolibarr's object (no need to check)
// $currentInvId = $_POST['imgClicked']; // from DOM elements : imgId (equals invoice id)

// $toJsonArray['makeRed'] = ($totalRemaining < price2num($result) || price2num($result) < 0) ? true : false;
// $toJsonArray['result'] = price($result); // Return value to user format
// $toJsonArray['resultnum'] = price2num($result); // Return value to numeric format

// Encode to JSON to return
// echo json_encode($toJsonArray); // Printing the call's result
